﻿namespace Generics_HistoryList
{
    public interface INameable
    {
        public string Fullname { get; }
    }
}