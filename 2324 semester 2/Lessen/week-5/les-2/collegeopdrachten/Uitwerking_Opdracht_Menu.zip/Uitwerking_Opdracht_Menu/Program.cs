﻿
using System.ComponentModel;
using Uitwerking_Opdracht_Menu;

var menu = new List<MenuItem>()
{
    new MenuItem("Hamburger",  562,  9.4,   2.5, false, true),
    new MenuItem("Milkshake",  344,   54,  0.51, true,  false),
    new MenuItem("Friet",      330,  0.4,  0.53, true,  false),
    new MenuItem("Vegaburger", 421,    7,   2.2, true,  true),
    new MenuItem("Salade",     137,  7.4,  0.66, false, true)
};


#region Opdracht Fastfood (zoek en sorteer) 
//Schrijf een query die alle items uit het menu met minder dan 1 gram zout teruggeeft.

var minderDan1GramZout_QuerySyntax = from m in menu
                         where m.Zout < 1
                         select m;

var minderDan1GramZout_MethodSyntax = menu.Where(m => m.Zout < 1);

foreach (var m in minderDan1GramZout_QuerySyntax) 
{
    Console.WriteLine($"{m.Omschrijving} bevat {m.Zout} gram zout");
}
Console.WriteLine();
foreach (var m in minderDan1GramZout_MethodSyntax) 
{
    Console.WriteLine($"{m.Omschrijving} bevat {m.Zout} gram zout");
}

//Schrijf een query die alle items uit het menu met ‘burger’ in de omschrijving terug geeft.
var burgerQuerySyntax = from m in menu where m.Omschrijving.ToLower().Contains("burger") select m;
var burgersMethodSyntax = menu.Where(m => m.Omschrijving.ToLower().Contains("burger"));

//Schrijf een query die de omschrijving van alle items uit het menu in het hoofdletters terug geeft en aflopend gesorteerd is. 
var aflopendeOmschrijvingenInHoofdlettersQuerySyntax = from m in menu orderby m.Omschrijving descending select m.Omschrijving.ToUpper();
var aflopendeOmchrijvingenInHoofdlettersMethodSyntax = menu.OrderByDescending(m => m.Omschrijving).Select(m => m.Omschrijving.ToUpper());



#endregion


#region Opdracht Fastfood (nesting)

//Schrijf een query die de hoeveelheid suiker selecteert van het item uit het menu met het meeste zout

var suikerVanItemMetMeesteZout = menu.Where(m => m.Zout == menu.Max(m => m.Zout)).Select(m => new { m.Omschrijving, m.Suikers });

foreach (var m in suikerVanItemMetMeesteZout)
{
    Console.WriteLine($"{m.Omschrijving} bevat {m.Suikers} gram suikers");
}
Console.WriteLine();


//Schrijf een query die de omschrijving van een item uit het menu selecteert met het minst aantal calorieën.
foreach (var m in menu.Where(m => m.KCal == menu.Min(m => m.KCal)).Select(m => m.Omschrijving)) 
{
    Console.WriteLine($"{m} heeft minst aantal calorieën");
}


#endregion


#region Opdracht Broodbeleg

var broodbelegKeuze = new List<string>() { "ham", "kaas", "boter", "ei", "rosbief", "pindakaas", "hagelslag", "hazelnootpasta", "jam" };

var broodbelegWoordlengte = from b in broodbelegKeuze select $"{b} heeft lengte van {b.Length}";
var broodbelegAflopendOpWoordlengte = from b in broodbelegKeuze orderby b.Length descending select $"{b} heeft lengte van {b.Length}";
var broodbelegMetMaximaleLengteVan4 = from b in broodbelegKeuze where b.Length <= 4 select $"{b} heeft lengte van {b.Length}";


#endregion